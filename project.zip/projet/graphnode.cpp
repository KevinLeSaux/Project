#include <iostream>
#include <vector>
#include <queue>
#include "graphnode.hpp"
#include "graphedge.hpp"
#include "graph.hpp"

using namespace std;

GraphNode::GraphNode(int id) : m_id(id) {}

int GraphNode::getId() const {

    return m_id;

}

void GraphNode::add_edge(GraphEdge* edge) {
    m_edges.push_back(edge); 
}

std::vector<GraphEdge*> GraphNode::getEdges() const {
    return m_edges;
}

void GraphNode::BFS(const int nbVert){

cout << "Id -> "<< this->getId() << " <- Id "<< endl;

    //Create a list to verify if a vertex as been visited
    bool* visited = new bool[nbVert];

    //Creat a list of the distance of the vertices from the start
    int* distance = new int[nbVert];

    //Default : nothing as been visited and the distance are 0
    for (int i = 0; i < nbVert; i++)
    {
        visited[i] = false;
        distance[0] = 0;
    }
    
    //Queue system
    queue<GraphNode*> queue;
    cout << "m_id : " << m_id << endl;
    //Starting node as been visited
    visited[m_id] = true;

    cout << visited[m_id] << endl;
    queue.push(this);

    

    while(!queue.empty()){
        //Take first element of the queue
        GraphNode* u = queue.front();
        cout << u->getId() << " ";
        //Erase this element from the queue
        queue.pop();

        //Get the list of the edges of the current node
        vector<GraphEdge*> list = u->getEdges();

        /*cout << "Size : " << list.size() << endl;*/
        for (int i = 0; i < list.size(); i++)
        {
            int v = list[i]->getDst()->getId();
            if (!visited[v])
            {
                distance[v] = distance[u->getId()] + 1;
                visited[v] = true;
                queue.push(list[i]->getDst());
            }
            
        }
        cout << "distance from start : " << distance[u->getId()] << " " << endl;

    }
    cout << endl;

}

void GraphNode::DFS(const int nbVert, vector<GraphNode*> list){
    //Create a list to verify if a vertex as been visited
    bool* visited = new bool[nbVert];

    //Creat a list of the distance of the vertices from the start
    int* distance = new int[nbVert];

    //Default : nothing as been visited and the distance are 0
    for (int i = 0; i < nbVert; i++)
    {
        visited[i] = false;
        distance[0] = 0;
    }

    int time = 0;

    for (int i = 0; i <3; i++)
    {
        /* code */
    }
    
}