#ifndef DEF_GRAPHNODE
#define DEF_GRAPHNODE

#include <vector>
#include "graphedge.hpp"
#include "graph.hpp"
class GraphEdge;
class GraphNode
{
    public:
        //Constructor
        GraphNode(int id);


        //Accessors
        int getId() const;
        std::vector<GraphEdge*>getEdges() const;
        //nbVert is the number of node in the graph
        void BFS(int nbVert);
        void DFS(int nbVert, std::vector<GraphNode*> listVert);
        
        //Mutator
        void add_edge(GraphEdge* edge);



    private:
        int m_id;
        std::vector<GraphEdge*> m_edges;
        

};



#endif