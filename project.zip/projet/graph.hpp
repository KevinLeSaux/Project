#ifndef DEF_GRAPH
#define DEF_GRAPH

#include <vector>
#include "graphedge.hpp"
#include "graphnode.hpp"
class GraphNode;
class GraphEdge;
class Graph
{
    public:
        //Constructor
       Graph();
        //Accessors
        std::vector<GraphNode *>getList();
        
        //Mutator

    private:
        
        std::vector<GraphNode*> m_list;
        

};



#endif